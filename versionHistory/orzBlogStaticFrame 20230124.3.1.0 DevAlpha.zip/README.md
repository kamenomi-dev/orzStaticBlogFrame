# Orz博客框架 (zh-CN)

>  一个静态博客框架

简介:  

  本静态博客框架采用了模块化(Namespace)的结构，可以让修改变得更加简单。  

  (How to use详见Wiki)  

依赖:

1. [TypeScript (ESNext)](https://github.com/microsoft/TypeScript)
2. [jQuery](https://github.com/jquery/jquery)
3. [jQuery-cookie](https://github.com/carhartl/jquery-cookie)
4. [jQuery-hoverIntent](https://github.com/briancherne/jquery-hoverIntent)
4. [ShowDown](https://github.com/showdownjs/showdown)

扩展:

1. 自定义插件支持
2. 自定义样式支持
3. 多语言支持

安全性:

1. 不要在上面公布你的个人信息，因为文章都是通过 XHR 获取的。
2. 因为此是开源项目，bug点显而易见，如果你有点担心，可以试试加密。

协议:

​	此项目使用了 麻省理工学院协议(MIT LICENSE)。

作者:

​	Creakler
